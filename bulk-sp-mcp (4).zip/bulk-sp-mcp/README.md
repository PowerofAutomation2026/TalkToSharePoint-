# Bulk SharePoint MCP Server — spobulkmcp continuation

A from-scratch rebuild of your existing SharePoint MCP server (the `ca-mcp`
container on `powerappsfargo2022`), keeping the **exact same 17-tool surface**
your Claude Desktop + Copilot Studio agent already use (`connect_list` →
`list_key` → operate), rebuilt clean on Azure Container Apps with proper
**>5,000-item large-list handling** and the **Copilot Studio direct-MCP fix**.

## The Copilot Studio fix (read this first)

Your server **already worked with Claude Desktop and not Copilot Studio.**
That's the whole clue. Claude Desktop connects via **DCR (Dynamic Client
Registration) with discovery** — it reads your server's `.well-known` OAuth
metadata and registers itself. Your FastMCP server serves that already.

You were pushing Copilot Studio down the **custom connector** path, which uses a
totally different OAuth flow through Power Platform's APIM proxy — the source of
every `invalid_token` 401 and AADSTS50011 redirect error you hit.

**Fix:** use Copilot Studio's **Dynamic discovery** MCP wizard (the same DCR
path Claude Desktop uses). No custom connector, no redirect-URI juggling. Full
steps in **COPILOT-STUDIO-SETUP.md**.

The server change that enables it: `allowed_client_redirect_uris` now permits
Copilot Studio's DCR callbacks alongside Claude's.

## Why this beats the 5,000-item threshold

SharePoint throttles any query that scans more than 5,000 rows. Only queries on
**indexed columns** survive. This server is built around that:

- `connect_list` and `list_schema` report which columns are **indexed**.
- `filter_records`, `aggregate_records`, `find_stale_items`, `export_to_csv`
  page through Graph's `@odata.nextLink` and send
  `Prefer: HonorNonIndexedQueriesWarningMayFailRandomly`.
- Everything uses **Microsoft Graph**, not SharePoint REST `/_api` (app-only
  tokens fail there).

## Tool surface (matches your existing connector)

**Connect/manage:** `connect_list`, `list_connected_lists`, `list_schema`, `refresh_cache`, `disconnect_list`
**Read:** `get_record_by_id`, `search_records`, `filter_records` (eq/ne/gt/lt/ge/le/contains/startswith), `find_stale_items`, `detect_duplicates`, `aggregate_records` (count/sum/avg/min/max + group_by), `export_to_csv`
**Write:** `create_item`, `bulk_create_tasks`, `update_item`, `delete_item`
**Util:** `whoami`

## Files

| File | Purpose |
|---|---|
| `server.py` | MCP server (17 tools + health) |
| `requirements.txt` | Pinned deps (fastmcp 3.2.4) |
| `Dockerfile` | Container image |
| `deploy.ps1` | One-shot: Entra app + Container App + all OAuth fixes |
| `COPILOT-STUDIO-SETUP.md` | **Direct-MCP Dynamic discovery setup (the fix)** |
| `claude_desktop_config.json` | Claude Desktop connector entry |
| `connector-apiDefinition.swagger.json` | Custom connector (fallback only) |
| `connector-apiProperties.json` | Custom connector (fallback only) |

## Your environment

- Tenant: `e6c360d6-57a5-473e-9188-3bfac0e3250e`
- Client ID: `441489f6-729b-47ef-b100-b35c49899fb8`
- Container App: `ca-mcp` (rg-mcp, env cae-mcp)
- MCP URL: `https://ca-mcp.braveflower-6ddf06f4.eastus.azurecontainerapps.io/mcp`
- Demo list: `https://powerappsfargo2022.sharepoint.com/sites/classicdemo/Lists/Copilot/AllItems.aspx`

## Deploy

```powershell
az login
cd bulk-sp-mcp
./deploy.ps1 -ResourceGroup rg-mcp -Location eastus -AppName bulk-sp-mcp -ContainerApp ca-mcp
```

Idempotent — reuses the existing `ca-mcp` and Entra app. Prints MCP URL, IDs,
scope, and the client secret (once).

## Connect Claude Desktop (already works)

Settings → Connectors → Add custom connector → `https://<fqdn>/mcp` → sign in.

## Connect Copilot Studio (the fix)

Follow **COPILOT-STUDIO-SETUP.md** — Tools → Add a tool → Model Context
Protocol → OAuth 2.0 → **Dynamic discovery**. That's the whole change.

## Every fix baked in

- **fastmcp pinned 3.2.4** — 3.4.x removed `custom_route(auth=)` and crash-looped.
- **v2 access tokens**, **identifier URI + user_impersonation** (correct audience).
- **Graph perms pre-consented** (no AADSTS90008 loop).
- **CORS**, **200 root route**, **Graph over SharePoint REST**.
- **Copilot Studio DCR callbacks allowlisted** — the direct-MCP enabler.

## Transport note

Copilot Studio is **Streamable HTTP only** (SSE dropped Aug 2025). Server runs
`transport="http"` at `/mcp` — already correct.

## invalid_token troubleshooting

```powershell
az containerapp logs show -g rg-mcp -n ca-mcp --follow --type console
```
`POST /mcp -> 401` = stale/wrong-audience token; delete + recreate the
connection. `-> 200` = tools populate.

## How the Graph token works (On-Behalf-Of)

The server receives the user's token (audience `api://441489f6...`) from Copilot
Studio or Claude Desktop, then exchanges it via **MSAL On-Behalf-Of** for a real
Microsoft Graph token (audience `https://graph.microsoft.com`). A single token
can't carry two audiences, so this exchange is required — without it Graph
returns `InvalidAuthenticationToken: Invalid audience`. The exchange uses the
app's client secret + the Graph delegated permissions that `deploy.ps1`
admin-consented. Nothing extra to configure.
