"""
Bulk SharePoint MCP Server  (v6.0)  —  spobulkmcp / spoherocobaby continuation
==============================================================================
Same tool surface your existing Copilot Studio + Claude Desktop connector uses:
connect once with connect_list (URL -> list_key), then operate by list_key.

Built for SharePoint lists OVER the 5,000-item List View Threshold:
  - connect_list caches the list locally (id + indexed columns)
  - filter_records / search_records page through Graph @odata.nextLink
  - filters run on indexed columns so the threshold error never fires
Natural language -> the model picks field/operator/value (or a filter string)
and these tools execute it safely against large lists.

Works with BOTH Claude Desktop (DCR) and Copilot Studio (on-behalf-of).
Auth: FastMCP AzureProvider (Entra ID), v2 tokens. All prior fixes baked in.
"""

import os
import re
import csv
import io
import logging
import datetime as dt
from typing import Any

import httpx
import msal
from fastmcp import FastMCP
from fastmcp.server.auth.providers.azure import AzureProvider
from starlette.requests import Request
from starlette.responses import JSONResponse, PlainTextResponse

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger("bulk-sp-mcp")
VERSION = "6.1"

CLIENT_ID = os.environ["AZURE_CLIENT_ID"]
CLIENT_SECRET = os.environ["AZURE_CLIENT_SECRET"]
TENANT_ID = os.environ["AZURE_TENANT_ID"]
BASE_URL = os.environ["MCP_BASE_URL"].rstrip("/")
PORT = int(os.environ.get("PORT", "8080"))
GRAPH = "https://graph.microsoft.com/v1.0"

auth_provider = AzureProvider(
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET,
    tenant_id=TENANT_ID,
    base_url=BASE_URL,
    required_scopes=["user_impersonation"],
    additional_authorize_scopes=[
        "https://graph.microsoft.com/Sites.Read.All",
        "https://graph.microsoft.com/Sites.ReadWrite.All",
        "https://graph.microsoft.com/User.Read",
    ],
    # Clients that may register via DCR and where the auth code is returned.
    # Claude Desktop already worked through these. The Copilot Studio entries
    # are what let its "Dynamic discovery" (DCR) wizard connect the SAME way,
    # with no custom connector.
    allowed_client_redirect_uris=[
        # Claude Desktop / Claude.ai
        "https://claude.ai/api/mcp/auth_callback",
        "https://claude.com/api/mcp/auth_callback",
        # Copilot Studio direct-MCP (Dynamic discovery / Dynamic) callbacks
        "https://*.copilotstudio.microsoft.com/*",
        "https://copilotstudio.microsoft.com/*",
        "https://*.powerplatform.com/*",
        "https://global.consent.azure-apim.net/redirect",
        "https://global.consent.azure-apim.net/redirect/*",
        # Power Platform token service (US + global)
        "https://token.botframework.com/*",
        "https://*.botframework.com/*",
    ],
)

mcp = FastMCP(name="bulk-sharepoint-mcp", auth=auth_provider)
log.info("Bulk SP MCP v%s init, tenant %s", VERSION, TENANT_ID)

# MSAL confidential client used for the On-Behalf-Of exchange:
# incoming user token (aud = api://CLIENT_ID)  ->  Graph token (aud = graph).
_msal_app = msal.ConfidentialClientApplication(
    client_id=CLIENT_ID,
    client_credential=CLIENT_SECRET,
    authority=f"https://login.microsoftonline.com/{TENANT_ID}",
)

# In-memory cache of connected lists, keyed by list_key (the display name).
_CONN: dict[str, dict[str, Any]] = {}
_OPS = {"eq", "ne", "gt", "lt", "ge", "le"}
_PREFER = {"Prefer": "HonorNonIndexedQueriesWarningMayFailRandomly"}


# --------------------------------------------------------------------------
# Graph plumbing
# --------------------------------------------------------------------------
def _graph_token() -> str:
    """
    Exchange the signed-in user's token (audience = api://CLIENT_ID, the value
    Copilot Studio / Claude Desktop sent us) for a Microsoft Graph access token
    via the On-Behalf-Of flow. A single token can't have two audiences, so this
    exchange is what gives us a token Graph will actually accept.
    """
    from fastmcp.server.dependencies import get_access_token
    token = get_access_token()
    # The raw incoming JWT, used as the OBO user assertion.
    assertion = (getattr(token, "token", None)
                 or getattr(token, "access_token", None)
                 or getattr(token, "jwt", None))
    if not assertion:
        raise RuntimeError("No incoming user token to exchange for Graph (OBO).")
    result = _msal_app.acquire_token_on_behalf_of(
        user_assertion=assertion,
        scopes=["https://graph.microsoft.com/.default"],
    )
    if "access_token" not in result:
        err = result.get("error")
        desc = (result.get("error_description") or "")[:300]
        raise RuntimeError(f"OBO exchange to Graph failed: {err}: {desc}")
    return result["access_token"]


async def _g(path: str, params=None, headers=None) -> dict:
    h = {"Authorization": f"Bearer {_graph_token()}", "Accept": "application/json"}
    if headers:
        h.update(headers)
    async with httpx.AsyncClient(timeout=60) as c:
        r = await c.get(f"{GRAPH}{path}", params=params, headers=h)
        if r.status_code >= 400:
            raise RuntimeError(f"Graph GET {path} -> {r.status_code}: {r.text[:400]}")
        return r.json()


async def _g_url(url: str) -> dict:
    h = {"Authorization": f"Bearer {_graph_token()}", "Accept": "application/json"}
    async with httpx.AsyncClient(timeout=60) as c:
        r = await c.get(url, headers=h)
        if r.status_code >= 400:
            raise RuntimeError(f"Graph next -> {r.status_code}: {r.text[:400]}")
        return r.json()


async def _g_write(method: str, path: str, body: dict) -> dict:
    h = {"Authorization": f"Bearer {_graph_token()}",
         "Accept": "application/json", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=60) as c:
        r = await c.request(method, f"{GRAPH}{path}", headers=h, json=body)
        if r.status_code >= 400:
            raise RuntimeError(f"Graph {method} {path} -> {r.status_code}: {r.text[:400]}")
        return r.json() if r.text else {}


def _parse_spo_url(url: str) -> tuple[str, str]:
    m = re.match(r"https?://([^/]+)(/sites/[^/]+|/teams/[^/]+)?/Lists/([^/]+)/", url, re.I)
    if not m:
        raise RuntimeError("URL must be a .../Lists/<Name>/AllItems.aspx link.")
    host, site_path, list_name = m.group(1), m.group(2) or "", m.group(3)
    site_ref = f"{host}:{site_path}" if site_path else host
    return site_ref, list_name


async def _resolve(site_ref: str, list_name: str) -> dict:
    site = await _g(f"/sites/{site_ref}")
    site_id = site["id"]
    lst = await _g(f"/sites/{site_id}/lists",
                   params={"$filter": f"displayName eq '{list_name}'",
                           "$select": "id,displayName,webUrl"})
    vals = lst.get("value", [])
    if not vals:
        raise RuntimeError(f"List '{list_name}' not found.")
    list_id = vals[0]["id"]
    web_url = vals[0].get("webUrl")
    cols = await _g(f"/sites/{site_id}/lists/{list_id}/columns",
                    params={"$select": "name,displayName,indexed"})
    indexed = [c["name"] for c in cols.get("value", []) if c.get("indexed")]
    return {"site_id": site_id, "list_id": list_id, "web_url": web_url,
            "indexed": indexed, "list_name": list_name}


def _need(list_key: str) -> dict:
    if list_key not in _CONN:
        raise RuntimeError(f"List '{list_key}' not connected. Run connect_list first.")
    return _CONN[list_key]


async def _page_items(conn: dict, odata_filter: str = "", order_by: str = "",
                      max_items: int = 500, select: str = "") -> list[dict]:
    params: dict[str, Any] = {"$top": min(max_items, 500)}
    params["expand"] = f"fields($select={select})" if select else "fields"
    if odata_filter:
        params["$filter"] = odata_filter
    if order_by:
        params["$orderby"] = order_by
    rows: list[dict] = []
    data = await _g(f"/sites/{conn['site_id']}/lists/{conn['list_id']}/items",
                    params=params, headers=_PREFER)
    while True:
        for it in data.get("value", []):
            rows.append(it.get("fields", {}))
            if len(rows) >= max_items:
                return rows
        nxt = data.get("@odata.nextLink")
        if not nxt:
            return rows
        data = await _g_url(nxt)


async def _count(conn: dict, odata_filter: str = "") -> int:
    params: dict[str, Any] = {"$top": 500, "$select": "id"}
    if odata_filter:
        params["$filter"] = odata_filter
    total = 0
    data = await _g(f"/sites/{conn['site_id']}/lists/{conn['list_id']}/items",
                    params=params, headers=_PREFER)
    while True:
        total += len(data.get("value", []))
        nxt = data.get("@odata.nextLink")
        if not nxt:
            return total
        data = await _g_url(nxt)


# --------------------------------------------------------------------------
# Connect / manage
# --------------------------------------------------------------------------
@mcp.tool
async def connect_list(url: str) -> dict:
    """
    Connect to a SharePoint list by its AllItems.aspx URL. Caches the list and
    returns a list_key (the display name), total item count, and which columns
    are INDEXED (the only safe ones to filter on for large lists).

    Args:
        url: Full SharePoint list URL, e.g.
             https://contoso.sharepoint.com/sites/HR/Lists/Tickets/AllItems.aspx
    """
    site_ref, list_name = _parse_spo_url(url)
    conn = await _resolve(site_ref, list_name)
    _CONN[list_name] = conn
    total = await _count(conn)
    return {"list_key": list_name, "web_url": conn["web_url"],
            "total_items": total, "indexed_columns": conn["indexed"]}


@mcp.tool
async def list_connected_lists() -> dict:
    """Show lists already connected in this session."""
    return {"connected": [
        {"list_key": k, "web_url": v["web_url"], "indexed_columns": v["indexed"]}
        for k, v in _CONN.items()
    ]}


@mcp.tool
async def list_schema(list_key: str) -> dict:
    """
    Show a connected list's columns, types, and which are indexed, plus a couple
    of sample rows. Call before filtering a large list.

    Args:
        list_key: The key returned by connect_list (the list display name).
    """
    conn = _need(list_key)
    cols = await _g(f"/sites/{conn['site_id']}/lists/{conn['list_id']}/columns",
                    params={"$select": "name,displayName,indexed,text,number,dateTime,boolean,choice"})
    out = []
    for c in cols.get("value", []):
        ctype = next((t for t in ("text", "number", "dateTime", "boolean", "choice")
                      if c.get(t) is not None), "unknown")
        out.append({"name": c.get("name"), "display": c.get("displayName"),
                    "indexed": bool(c.get("indexed")), "type": ctype})
    sample = await _page_items(conn, max_items=2)
    return {"list_key": list_key, "indexed_columns": conn["indexed"],
            "columns": out, "sample": sample}


@mcp.tool
async def refresh_cache(list_key: str) -> dict:
    """
    Re-pull a connected list's indexed columns.

    Args:
        list_key: The connected list key.
    """
    conn = _need(list_key)
    cols = await _g(f"/sites/{conn['site_id']}/lists/{conn['list_id']}/columns",
                    params={"$select": "name,indexed"})
    conn["indexed"] = [c["name"] for c in cols.get("value", []) if c.get("indexed")]
    return {"list_key": list_key, "indexed_columns": conn["indexed"], "refreshed": True}


@mcp.tool
async def disconnect_list(list_key: str) -> dict:
    """
    Drop a list from the session cache.

    Args:
        list_key: The connected list key.
    """
    _CONN.pop(list_key, None)
    return {"list_key": list_key, "disconnected": True}


# --------------------------------------------------------------------------
# Read
# --------------------------------------------------------------------------
@mcp.tool
async def get_record_by_id(list_key: str, item_id: str) -> dict:
    """
    Fetch one item by id (never throttled).

    Args:
        list_key: The connected list key.
        item_id: Numeric item id.
    """
    conn = _need(list_key)
    data = await _g(f"/sites/{conn['site_id']}/lists/{conn['list_id']}/items/{item_id}",
                    params={"expand": "fields"})
    return {"list_key": list_key, "item": data.get("fields", {})}


@mcp.tool
async def filter_records(list_key: str, field: str, operator: str, value: str,
                         top_k: int = 200) -> dict:
    """
    Filter a list by one field/operator/value, safe on lists over 5,000 items.
    Filter on an INDEXED column (see list_schema) to avoid the threshold error.

    Args:
        list_key: The connected list key.
        field: Column internal name, e.g. 'Title', 'Status', 'Priority'.
        operator: eq, ne, gt, lt, ge, le, contains, or startswith.
        value: The value to match.
        top_k: Max rows to return (default 200).
    """
    conn = _need(list_key)
    fr = f"fields/{field}"
    op = operator.lower()
    if op in _OPS:
        v = value if value.replace(".", "", 1).isdigit() else f"'{value}'"
        flt = f"{fr} {op} {v}"
    elif op == "contains":
        flt = f"contains({fr},'{value}')"
    elif op == "startswith":
        flt = f"startswith({fr},'{value}')"
    else:
        raise RuntimeError("operator must be eq/ne/gt/lt/ge/le/contains/startswith")
    rows = await _page_items(conn, odata_filter=flt, max_items=min(top_k, 2000))
    return {"list_key": list_key, "filter": flt, "returned": len(rows), "items": rows}


@mcp.tool
async def search_records(list_key: str, query: str, top_k: int = 50) -> dict:
    """
    Keyword search across the list (matches Title contains). For precise column
    filters use filter_records.

    Args:
        list_key: The connected list key.
        query: Free-text search terms.
        top_k: Max rows (default 50).
    """
    conn = _need(list_key)
    rows = await _page_items(conn, odata_filter=f"contains(fields/Title,'{query}')",
                             max_items=min(top_k, 1000))
    return {"list_key": list_key, "query": query, "returned": len(rows), "items": rows}


@mcp.tool
async def aggregate_records(list_key: str, operation: str = "count",
                            field: str = "", group_by: str = "",
                            odata_filter: str = "") -> dict:
    """
    Aggregate over a (optionally filtered) list: count/sum/avg/min/max, with an
    optional group_by. Pages through all matches.

    Args:
        list_key: The connected list key.
        operation: count, sum, avg, min, max.
        field: Column to aggregate (required for sum/avg/min/max).
        group_by: Optional column to group by.
        odata_filter: Optional OData filter on indexed fields to scope it.
    """
    conn = _need(list_key)
    op = operation.lower()
    if op == "count" and not group_by and not odata_filter:
        return {"list_key": list_key, "operation": "count", "count": await _count(conn)}
    select = ",".join(x for x in {field, group_by} if x) or "id"
    rows = await _page_items(conn, odata_filter=odata_filter, max_items=2000, select=select)
    if not group_by:
        if op == "count":
            return {"list_key": list_key, "operation": "count", "count": len(rows)}
        nums = [float(r[field]) for r in rows if r.get(field) not in (None, "")]
        if not nums:
            return {"list_key": list_key, "operation": op, "result": None}
        res = {"sum": sum(nums), "avg": sum(nums) / len(nums),
               "min": min(nums), "max": max(nums)}[op]
        return {"list_key": list_key, "operation": op, "field": field, "result": res}
    groups: dict[str, list[dict]] = {}
    for r in rows:
        groups.setdefault(str(r.get(group_by, "")), []).append(r)
    out: dict[str, Any] = {}
    for k, g in groups.items():
        if op == "count":
            out[k] = len(g)
        else:
            nums = [float(x[field]) for x in g if x.get(field) not in (None, "")]
            if not nums:
                out[k] = None
            else:
                out[k] = {"sum": sum(nums), "avg": sum(nums) / len(nums),
                          "min": min(nums), "max": max(nums)}[op]
    return {"list_key": list_key, "operation": op, "group_by": group_by, "groups": out}


@mcp.tool
async def find_stale_items(list_key: str, days: int = 90, top_k: int = 200) -> dict:
    """
    Items not modified in the last N days (Modified is always indexed).

    Args:
        list_key: The connected list key.
        days: Age threshold in days.
        top_k: Max rows.
    """
    conn = _need(list_key)
    cutoff = (dt.datetime.utcnow() - dt.timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")
    flt = f"fields/Modified le {cutoff}"
    rows = await _page_items(conn, odata_filter=flt, order_by="fields/Modified asc",
                             max_items=min(top_k, 2000))
    return {"list_key": list_key, "older_than_days": days,
            "returned": len(rows), "items": rows}


@mcp.tool
async def detect_duplicates(list_key: str, field: str, top_k: int = 2000) -> dict:
    """
    Find rows sharing the same value in a field.

    Args:
        list_key: The connected list key.
        field: Column to check for duplicate values.
        top_k: Max rows to scan.
    """
    conn = _need(list_key)
    rows = await _page_items(conn, max_items=min(top_k, 2000), select=f"{field},id")
    seen: dict[str, list] = {}
    for r in rows:
        seen.setdefault(str(r.get(field, "")), []).append(r.get("id"))
    dups = {k: v for k, v in seen.items() if len(v) > 1}
    return {"list_key": list_key, "field": field, "duplicate_groups": dups,
            "duplicate_value_count": len(dups)}


@mcp.tool
async def export_to_csv(list_key: str, odata_filter: str = "", max_items: int = 2000) -> dict:
    """
    Export list rows (optionally filtered) to CSV text.

    Args:
        list_key: The connected list key.
        odata_filter: Optional OData filter on indexed fields.
        max_items: Row cap (default 2000).
    """
    conn = _need(list_key)
    rows = await _page_items(conn, odata_filter=odata_filter, max_items=min(max_items, 2000))
    if not rows:
        return {"list_key": list_key, "rows": 0, "csv": ""}
    cols = sorted({k for r in rows for k in r.keys()})
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
    w.writeheader()
    for r in rows:
        w.writerow(r)
    return {"list_key": list_key, "rows": len(rows), "csv": buf.getvalue()}


# --------------------------------------------------------------------------
# Write
# --------------------------------------------------------------------------
@mcp.tool
async def create_item(list_key: str, fields: dict) -> dict:
    """
    Create one list item.

    Args:
        list_key: The connected list key.
        fields: Dict of column->value, e.g. {"Title": "New ticket"}.
    """
    conn = _need(list_key)
    data = await _g_write("POST",
                          f"/sites/{conn['site_id']}/lists/{conn['list_id']}/items",
                          {"fields": fields})
    return {"list_key": list_key, "created_id": data.get("id"),
            "item": data.get("fields", {})}


@mcp.tool
async def bulk_create_tasks(list_key: str, items: list) -> dict:
    """
    Create many list items. Each entry is a fields dict.

    Args:
        list_key: The connected list key.
        items: List of fields dicts, e.g. [{"Title":"a"},{"Title":"b"}].
    """
    conn = _need(list_key)
    created = []
    for f in items:
        d = await _g_write("POST",
                           f"/sites/{conn['site_id']}/lists/{conn['list_id']}/items",
                           {"fields": f})
        created.append(d.get("id"))
    return {"list_key": list_key, "created": len(created), "ids": created}


@mcp.tool
async def update_item(list_key: str, item_id: str, fields: dict) -> dict:
    """
    Update fields on one item.

    Args:
        list_key: The connected list key.
        item_id: Numeric item id.
        fields: Dict of column->new value.
    """
    conn = _need(list_key)
    data = await _g_write("PATCH",
                          f"/sites/{conn['site_id']}/lists/{conn['list_id']}/items/{item_id}/fields",
                          fields)
    return {"list_key": list_key, "item_id": item_id, "updated": data}


@mcp.tool
async def delete_item(list_key: str, item_id: str) -> dict:
    """
    Delete (recycle) one item.

    Args:
        list_key: The connected list key.
        item_id: Numeric item id.
    """
    conn = _need(list_key)
    await _g_write("DELETE",
                   f"/sites/{conn['site_id']}/lists/{conn['list_id']}/items/{item_id}",
                   {})
    return {"list_key": list_key, "item_id": item_id, "deleted": True}


@mcp.tool
async def whoami() -> dict:
    """Return the signed-in user (connectivity test)."""
    me = await _g("/me", params={"$select": "displayName,userPrincipalName,id"})
    return {"signed_in_as": me}


# --------------------------------------------------------------------------
# Health
# --------------------------------------------------------------------------
@mcp.custom_route("/healthz", methods=["GET"])
async def healthz(_req: Request) -> JSONResponse:
    return JSONResponse({"status": "ok", "service": "bulk-sharepoint-mcp",
                         "version": VERSION,
                         "time": dt.datetime.utcnow().isoformat() + "Z"})


@mcp.custom_route("/", methods=["GET"])
async def root(_req: Request) -> PlainTextResponse:
    return PlainTextResponse(f"Bulk SP MCP v{VERSION} — MCP endpoint at /mcp")


if __name__ == "__main__":
    log.info("Bulk SP MCP v%s starting on 0.0.0.0:%s", VERSION, PORT)
    mcp.run(transport="http", host="0.0.0.0", port=PORT)
