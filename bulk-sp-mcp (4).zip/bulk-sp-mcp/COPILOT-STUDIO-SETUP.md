# Connect Copilot Studio — DIRECT MCP (no custom connector)

This is the fix. Your server already works with Claude Desktop because it
supports **DCR (Dynamic Client Registration) with discovery**. Copilot Studio
supports the *same* mechanism via its **Dynamic discovery** wizard option.
Use that and you skip the entire custom-connector / redirect-URI mess.

## Why the custom connector kept failing

The custom connector path routes OAuth through Power Platform's APIM proxy
(`global.consent.azure-apim.net`), which mints tokens with a different audience
and forces per-connector redirect URIs into Entra. That mismatch was the source
of the `invalid_token` 401 and the AADSTS50011 redirect errors.

Claude Desktop never used that path — it used DCR discovery against your
server's `.well-known` metadata. Copilot Studio can now do exactly the same.

## Setup (5 minutes)

### 1. Confirm the server advertises discovery

Your FastMCP server already serves these. Verify:

```
https://ca-mcp.braveflower-6ddf06f4.eastus.azurecontainerapps.io/.well-known/oauth-protected-resource
https://ca-mcp.braveflower-6ddf06f4.eastus.azurecontainerapps.io/.well-known/oauth-authorization-server
```

Both should return JSON (200). If they do, Dynamic discovery will work.

### 2. Add the MCP server in Copilot Studio

1. Open your agent → **Tools** → **Add a tool** → **New tool** → **Model Context Protocol**.
2. Fill in:
   - **Server name:** Bulk SharePoint
   - **Server description:** Search, filter, and aggregate SharePoint lists over 5,000 items by natural language.
   - **Server URL:** `https://ca-mcp.braveflower-6ddf06f4.eastus.azurecontainerapps.io/mcp`
3. **Authentication:** select **OAuth 2.0** → type **Dynamic discovery**.
4. Select **Create**. Copilot Studio reads the discovery endpoint and registers itself automatically.

### 3. If a callback URL appears, add it to Entra (only if prompted)

Dynamic discovery usually needs nothing. But if the wizard shows a **callback URL**, copy it and add it to the Entra app once:

```powershell
$app = "441489f6-729b-47ef-b100-b35c49899fb8"
$existing = az ad app show --id $app --query "web.redirectUris" -o json | ConvertFrom-Json
$all = @($existing) + "<paste callback url>" | Select-Object -Unique
az ad app update --id $app --web-redirect-uris $all
```

### 4. Create the connection and test

1. Select **Next** → the Add tool dialog → **Create a new connection** → **Create**.
2. Sign in with your maker account → **Add and configure**.
3. Tools appear automatically (no manual fetch). Test: ask the agent
   *"who am I signed in as"*, then *"connect to the Copilot list and count items"*.

## Important transport note

Copilot Studio supports **Streamable HTTP only** (SSE was dropped after
August 2025). Your server runs `transport="http"` (streamable) at `/mcp`, so
you're already correct. Do not switch to SSE.

## If Dynamic discovery isn't available in your tenant

Some tenants only expose **Dynamic** (DCR without discovery). Then:
- Type: **Dynamic**
- **Authorization URL:** `https://login.microsoftonline.com/e6c360d6-57a5-473e-9188-3bfac0e3250e/oauth2/v2.0/authorize`
- **Token URL template:** `https://login.microsoftonline.com/e6c360d6-57a5-473e-9188-3bfac0e3250e/oauth2/v2.0/token`
- Copy the callback URL it generates → add to Entra (step 3).

Only fall back to the **custom connector** (the two `connector-*.json` files in
this package) if both Dynamic options are disabled in your environment.

## Live verification

```powershell
az containerapp logs show -g rg-mcp -n ca-mcp --follow --type console
```

Watch the `POST /mcp` line during connect/test:
- `401 invalid_token` → token not accepted (stale or wrong audience). Delete the connection in Copilot Studio, reconnect.
- `200` → tools load. Done.
