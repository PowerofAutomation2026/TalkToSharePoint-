<#
  deploy.ps1 — Bulk SharePoint MCP, from scratch
  ==============================================
  Provisions EVERYTHING:
    1. Entra app registration (v2 tokens, identifier URI, user_impersonation,
       Graph delegated perms, admin consent)
    2. Azure Container App (ACR build, external ingress, CORS, secret wiring)
    3. Prints the values you need for Claude Desktop + Copilot Studio

  Re-runnable (idempotent). Safe to run again after any change.

  USAGE:
    az login
    ./deploy.ps1 -ResourceGroup rg-mcp -Location eastus -AppName bulk-sp-mcp -ContainerApp ca-mcp
#>

param(
  [string]$ResourceGroup = "rg-mcp",
  [string]$Location      = "eastus",
  [string]$AppName       = "bulk-sp-mcp",
  [string]$ContainerApp  = "ca-mcp",
  [string]$Env           = "cae-mcp"
)

$ErrorActionPreference = "Stop"

# Fix the Windows 'charmap codec can't encode' crash in `az containerapp up`:
# force the console + Python to UTF-8 before any az build-log streaming runs.
try { chcp 65001 | Out-Null } catch {}
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env:PYTHONIOENCODING = "utf-8"
$env:PYTHONUTF8 = "1"

function Step($m){ Write-Host "`n>>> $m" -ForegroundColor Cyan }
function Ok($m){ Write-Host "  OK $m" -ForegroundColor Green }
function Warn($m){ Write-Host "  ! $m" -ForegroundColor Yellow }

# ---------------------------------------------------------------------------
Step "0. Verify login + providers"
$me = az account show --query user.name -o tsv
Ok "Signed in as $me"
$TenantId = az account show --query tenantId -o tsv
Ok "Tenant $TenantId"
az provider register --namespace Microsoft.App --wait | Out-Null
az provider register --namespace Microsoft.OperationalInsights --wait | Out-Null

# ---------------------------------------------------------------------------
Step "1. Resource group + Container Apps environment"
az group create -n $ResourceGroup -l $Location | Out-Null
$envExists = az containerapp env show -n $Env -g $ResourceGroup --query name -o tsv 2>$null
if (-not $envExists) {
  az containerapp env create -n $Env -g $ResourceGroup -l $Location | Out-Null
}
Ok "Environment $Env ready"

# ---------------------------------------------------------------------------
Step "2. Entra app registration"
$appId = az ad app list --display-name $AppName --query "[0].appId" -o tsv
if (-not $appId) {
  $appId = az ad app create --display-name $AppName --sign-in-audience AzureADMyOrg --query appId -o tsv
  Start-Sleep 10
}
Ok "Client ID $appId"
$objId = az ad app show --id $appId --query id -o tsv

# Identifier URI api://<appId>
az ad app update --id $appId --identifier-uris "api://$appId" 2>$null | Out-Null
Ok "Identifier URI api://$appId"

# requestedAccessTokenVersion = 2  (FastMCP requires v2)
# Write the body to a temp file — inline --body JSON fails on Windows PowerShell
# quoting ("Unable to read JSON request payload").
$patchFile = Join-Path $env:TEMP "mcp_tokenver.json"
'{"api":{"requestedAccessTokenVersion":2}}' | Out-File -FilePath $patchFile -Encoding ascii -NoNewline
az rest --method PATCH `
  --uri "https://graph.microsoft.com/v1.0/applications/$objId" `
  --headers "Content-Type=application/json" `
  --body "@$patchFile" 2>$null | Out-Null
Remove-Item $patchFile -ErrorAction SilentlyContinue
$ver = az ad app show --id $appId --query "api.requestedAccessTokenVersion" -o tsv
if ($ver -eq "2") { Ok "Access token version -> 2" } else { Warn "Token version is '$ver' (expected 2) — set it in Entra portal: App > Manifest > requestedAccessTokenVersion: 2" }

# Expose user_impersonation scope
$existingScopes = az ad app show --id $appId --query "api.oauth2PermissionScopes[].value" -o tsv
if ($existingScopes -notmatch "user_impersonation") {
  $scopeId = [guid]::NewGuid().ToString()
  $scopeBody = @{
    api = @{ oauth2PermissionScopes = @(@{
      id = $scopeId; adminConsentDescription = "Access the API as the signed-in user";
      adminConsentDisplayName = "Access API"; isEnabled = $true; type = "User";
      userConsentDescription = "Access the API as you"; userConsentDisplayName = "Access API";
      value = "user_impersonation"
    }) }
  } | ConvertTo-Json -Depth 8
  az rest --method PATCH `
    --uri "https://graph.microsoft.com/v1.0/applications/$objId" `
    --headers "Content-Type=application/json" --body $scopeBody | Out-Null
}
Ok "Scope user_impersonation exposed"

# Graph delegated permissions
$GRAPH = "00000003-0000-0000-c000-000000000000"
# User.Read, Sites.Read.All, Sites.ReadWrite.All, offline_access, openid, profile
$perms = @(
  "e1fe6dd8-ba31-4d61-89e7-88639da4683d",  # User.Read
  "205e70e5-aba6-4c52-a976-6d2d46c48043",  # Sites.Read.All
  "89fe6a52-be36-487e-b7d8-d061c450a026",  # Sites.ReadWrite.All
  "7427e0e9-2fba-42fe-b0c0-848c9e6a8182",  # offline_access
  "37f7f235-527c-4136-accd-4a02d197296e",  # openid
  "14dad69e-099b-42c9-810b-d002981feec1"   # profile
)
foreach ($p in $perms) {
  az ad app permission add --id $appId --api $GRAPH --api-permissions "$p=Scope" 2>$null | Out-Null
}
Ok "Graph delegated permissions declared"

# Service principal + admin consent
$spExists = az ad sp show --id $appId --query id -o tsv 2>$null
if (-not $spExists) { az ad sp create --id $appId | Out-Null; Start-Sleep 5 }
Start-Sleep 5
az ad app permission admin-consent --id $appId 2>$null
Ok "Admin consent granted (service principal ready)"

# Client secret (create fresh, capture once)
$secret = az ad app credential reset --id $appId --append --query password -o tsv
Ok "Client secret generated (shown once below)"

# ---------------------------------------------------------------------------
Step "3. Build + deploy container"

# Find or create an ACR (containerapp up auto-creates one; we do it explicitly
# so we control the build and skip the crash-prone log streaming).
$acr = az acr list -g $ResourceGroup --query "[0].name" -o tsv 2>$null
if (-not $acr) {
  $acr = ("acrmcp" + (Get-Random -Minimum 10000 -Maximum 99999))
  az acr create -g $ResourceGroup -n $acr --sku Basic --admin-enabled true | Out-Null
}
Ok "ACR $acr"

$tag = "v6-" + (Get-Date -Format "yyyyMMddHHmmss")
$image = "$acr.azurecr.io/ca-mcp:$tag"

# Build in ACR. --no-logs avoids the Windows 'charmap' UnicodeEncodeError that
# crashes `containerapp up` while streaming the build output.
Ok "Building image in ACR (no log stream)..."
az acr build -r $acr -t "ca-mcp:$tag" . --no-logs | Out-Null
Ok "Image built: $image"

# Does the container app already exist? If yes, update its image; if no, create.
$exists = az containerapp show -n $ContainerApp -g $ResourceGroup --query name -o tsv 2>$null
$acrServer = "$acr.azurecr.io"
$acrUser = az acr credential show -n $acr --query username -o tsv
$acrPass = az acr credential show -n $acr --query "passwords[0].value" -o tsv

if ($exists) {
  az containerapp registry set -n $ContainerApp -g $ResourceGroup `
    --server $acrServer --username $acrUser --password $acrPass | Out-Null
  az containerapp update -n $ContainerApp -g $ResourceGroup --image $image | Out-Null
  Ok "Updated existing $ContainerApp to new image"
} else {
  az containerapp create -n $ContainerApp -g $ResourceGroup --environment $Env `
    --image $image --target-port 8080 --ingress external `
    --registry-server $acrServer --registry-username $acrUser --registry-password $acrPass | Out-Null
  Ok "Created $ContainerApp"
}

$fqdn = az containerapp show -n $ContainerApp -g $ResourceGroup --query properties.configuration.ingress.fqdn -o tsv
$baseUrl = "https://$fqdn"
Ok "Deployed at $baseUrl"

# Secret + env wiring
az containerapp secret set -n $ContainerApp -g $ResourceGroup `
  --secrets "client-secret=$secret" | Out-Null
az containerapp update -n $ContainerApp -g $ResourceGroup `
  --set-env-vars `
    "AZURE_CLIENT_ID=$appId" `
    "AZURE_TENANT_ID=$TenantId" `
    "AZURE_CLIENT_SECRET=secretref:client-secret" `
    "MCP_BASE_URL=$baseUrl" | Out-Null
Ok "Env vars + secret wired"

# CORS for Copilot Studio / Power Platform
az containerapp ingress cors enable -n $ContainerApp -g $ResourceGroup `
  --allowed-origins "https://make.powerapps.com" "https://*.powerapps.com" `
                    "https://copilotstudio.microsoft.com" "https://*.microsoft.com" "https://claude.ai" `
  --allowed-methods "GET" "POST" "OPTIONS" `
  --allowed-headers "*" 2>$null | Out-Null
Ok "CORS configured"

# Redirect URIs (server callback + Claude.ai + Power Platform base)
$redirects = @(
  "$baseUrl/auth/callback",
  "https://claude.ai/api/mcp/auth_callback",
  "https://claude.com/api/mcp/auth_callback",
  "https://global.consent.azure-apim.net/redirect"
)
az ad app update --id $appId --web-redirect-uris @redirects | Out-Null
Ok "Redirect URIs registered"

az containerapp revision restart -n $ContainerApp -g $ResourceGroup `
  --revision (az containerapp show -n $ContainerApp -g $ResourceGroup --query properties.latestRevisionName -o tsv) 2>$null | Out-Null

# ---------------------------------------------------------------------------
Step "4. Verify the new image is actually live"
Start-Sleep 20
$healthOk = $false
for ($i = 0; $i -lt 6; $i++) {
  try {
    $h = Invoke-RestMethod -Uri "$baseUrl/healthz" -TimeoutSec 15
    if ($h.version -eq "6.1") { Ok "Health check: version $($h.version) live"; $healthOk = $true; break }
    else { Warn "Health returned version '$($h.version)', expected 6.1 - retrying..." }
  } catch { Warn "Health not ready yet (try $($i+1)/6)..." }
  Start-Sleep 15
}
if (-not $healthOk) {
  Warn "Could not confirm v6.1 at $baseUrl/healthz. Check logs:"
  Warn "  az containerapp logs show -g $ResourceGroup -n $ContainerApp --tail 40 --type console"
}

# ---------------------------------------------------------------------------
Write-Host "`n===============================================================" -ForegroundColor Green
Write-Host "  DONE — Bulk SP MCP deployed" -ForegroundColor Green
Write-Host "===============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  MCP URL (Claude Desktop + Copilot):  $baseUrl/mcp"
Write-Host "  Health:                              $baseUrl/healthz"
Write-Host ""
Write-Host "  Client ID:      $appId"
Write-Host "  Tenant ID:      $TenantId"
Write-Host "  Identifier URI: api://$appId"
Write-Host "  Scope:          api://$appId/user_impersonation openid profile"
Write-Host ""
Write-Host "  CLIENT SECRET (copy now, shown once):" -ForegroundColor Yellow
Write-Host "    $secret" -ForegroundColor Yellow
Write-Host ""
Write-Host "  NEXT:"
Write-Host "   - Claude Desktop: add custom connector -> $baseUrl/mcp -> Connect -> sign in"
Write-Host "   - Copilot Studio: import the connector files, paste this secret,"
Write-Host "     copy the NEW redirect URL it generates, then run:"
Write-Host "       az ad app update --id $appId --web-redirect-uris (existing...) <newUrl>"
